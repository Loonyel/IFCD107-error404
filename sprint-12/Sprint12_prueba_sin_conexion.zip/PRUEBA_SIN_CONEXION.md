# Sprint 12 · Prueba sin conexión

1. Descomprime el ZIP y abre la carpeta en VS Code o Jupyter. Deja `datos/` junto a los tres cuadernos.
2. Antes de desconectarte, comprueba que tu entorno local tiene Python, Jupyter (o VS Code con las extensiones Python y Jupyter), NumPy, pandas, scikit-learn, statsmodels y Matplotlib instalados.
3. Desconecta internet. En cada cuaderno selecciona el kernel local, reinícialo y ejecuta todas las celdas, en este orden: `resenas.ipynb`, `ocupacion.ipynb`, `asistente_rag.ipynb`. Abre los cuadernos desde la carpeta descomprimida para que encuentren `datos/`.
4. Comprueba estas salidas: exactitud de reseñas **0,992**, MAE de SARIMAX **3,18** frente a **4,46** del baseline semanal y asistente **24/25**, con **0 sin fuente** y **0 alucinaciones detectadas**. Se deben generar `grafico_resenas.png` y `evaluacion_asistente.csv` en la carpeta de ejecución.

## Comprobación realizada

El 24/11/2026 se ejecutaron completos los tres cuadernos adjuntados, cada uno en un proceso nuevo, con los cuatro archivos locales y el acceso a red de Python bloqueado durante la ejecución. Los tres resultados de control coincidieron con los de Colab.

Versiones de esta prueba local: Python 3.12.14, NumPy 2.3.5, pandas 2.2.3, scikit-learn 1.8.0, statsmodels 0.15.0 y Matplotlib 3.10.8. Son las del entorno de verificación, distintas de las registradas en Colab. Si tenéis una edición posterior de algún cuaderno, sustituid su copia y repetid la prueba para que la evidencia corresponda a esa versión.
